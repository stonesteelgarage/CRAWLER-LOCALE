# Configurazione locale
# Copia qui la tua chiave OpenAI

OPENAI_API_KEY = "sk-INSERISCI-LA-TUA-CHIAVE"

# Logo opzionale nella stessa cartella dell'app
LOGO_PATH = "logo.png"

# Password opzionale. Se lasci vuoto, non chiede login.
APP_PASSWORD = ""

# Modello OpenAI consigliato
MODEL_NAME = "gpt-4.1-mini"
